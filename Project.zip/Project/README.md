This is my final project for Javascript Module course.

I decided to build a cat fact generator, as I have 2 cats of my own. 

How it works is simple, click on the link and click on the button on the main page. A few random cat facts will pop up. Have fun!